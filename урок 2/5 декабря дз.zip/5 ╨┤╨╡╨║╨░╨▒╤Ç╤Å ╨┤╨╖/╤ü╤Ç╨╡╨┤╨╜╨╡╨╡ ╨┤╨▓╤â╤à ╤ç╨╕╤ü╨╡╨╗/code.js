var a = Number(prompt("введите первое число"));
var b = Number(prompt("введите второе число"));
//var a = Number(a);
//var b = Number(b);
var c = (a+b)/2 ;
alert("среднее двух чисел = " + c); 